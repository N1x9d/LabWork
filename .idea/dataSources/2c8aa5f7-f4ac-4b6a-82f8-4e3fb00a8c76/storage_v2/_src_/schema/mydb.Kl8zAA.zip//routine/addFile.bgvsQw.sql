create
    definer = root@localhost procedure addFile(IN fname varchar(40), IN Patch varchar(100), IN dirPatch varchar(100))
BEGIN
declare  DIRid int default 0;
select ID from dir where patch = dirPatch into DIRid;
insert into file (Fname,Patch,Dir_ID) values (fname,Patch,Dirid);
END;

