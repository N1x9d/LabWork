create
    definer = root@localhost procedure addWord(IN word varchar(40), IN Count int, IN FPatch varchar(100))
BEGIN
declare  DIRid int default 0;
select ID from file where patch = FPatch into DIRid;
insert into file (Word,Count,File_ID) values (word,Count,Dirid);
END;

