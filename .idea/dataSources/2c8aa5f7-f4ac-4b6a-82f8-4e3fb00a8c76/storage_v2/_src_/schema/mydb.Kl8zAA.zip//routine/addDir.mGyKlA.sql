create
    definer = root@localhost procedure addDir(IN dir varchar(40), IN patch varchar(100))
BEGIN
insert into dir (DirName,patch) values (dir,patch);
END;

